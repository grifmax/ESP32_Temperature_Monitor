#ifndef SENSORS_H
#define SENSORS_H

void readTemperature();

#endif
