#ifndef CONFIG_H
#define CONFIG_H

// --- GPIO Pin Definitions ---
#define TEMP_SENSOR_PIN   4       // DS18B20 Data Pin
#define OLED_SDA_PIN      8       // OLED SDA Pin
#define OLED_SCL_PIN      9       // OLED SCL Pin
#define BATTERY_MONITOR_PIN 0    // GPIO for Battery Monitoring
#define BUTTON_PIN        6       // GPIO для кнопки
#define BUZZER_PIN        5       // GPIO для зуммера

// --- Wi-Fi credentials ---
#define WIFI_SSID         "your-SSID"
#define WIFI_PASSWORD     "your-PASSWORD"

// --- Telegram Bot settings ---
#define TELEGRAM_BOT_TOKEN    "your-telegram-bot-token"
#define TELEGRAM_CHAT_ID      "your-chat-id"

// --- MQTT settings ---
#define MQTT_SERVER          "mqtt.server.com"
#define MQTT_PORT            1883
#define MQTT_USER            "mqtt_username"
#define MQTT_PASSWORD        "mqtt_password"
#define MQTT_TOPIC_STATUS    "home/thermo/status"
#define MQTT_TOPIC_CONTROL   "home/thermo/control"
#define MQTT_TOPIC_CONFIG    "home/thermo/config"
#define MQTT_TOPIC_ALARMS    "home/thermo/alarms"

// --- Temperature Alarm Thresholds ---
#define HIGH_TEMP_THRESHOLD   30.0
#define LOW_TEMP_THRESHOLD    10.0

// --- Battery settings ---
#define BATTERY_VOLTAGE_DIVIDER 2

#endif
