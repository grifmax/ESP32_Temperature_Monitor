#ifndef WEB_SERVER_H
#define WEB_SERVER_H

void startWebServer();
void handleClient();

#endif
