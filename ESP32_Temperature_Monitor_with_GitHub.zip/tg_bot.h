#ifndef TG_BOT_H
#define TG_BOT_H

#include <UniversalTelegramBot.h>

void startTelegramBot();
void handleTelegramMessages();

#endif
